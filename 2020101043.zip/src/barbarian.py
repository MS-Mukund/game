from colorama import Fore, Back, Style, init
init()

from os import system
from time import sleep, time
import math