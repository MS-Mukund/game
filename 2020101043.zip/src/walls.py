# from colorama import Fore, Back, Style, init
# init()

# from os import system
# from time import sleep, time
# import math

# import sys
# sys.path.insert(0, '/src')
# from building import Building 

# class Walls(Building):
#     def __init__(self, tuple):
#         # print(tuple)
#         x, y, id = tuple
#         Building.__init__(self, x, y, id, 1, 1, Back.WHITE + ' ' + Style.RESET_ALL, 15, 15)

#         # dimensions of walls
#         # self.height = 1
#         # self.width  = 1

#         # color of walls
#         # self.pixel = Back.WHITE + ' ' + Style.RESET_ALL

#         # properties of walls
#         # self.max_health = 15
#         # self.health = self.max_health
